angular.module("mebo", [
    'angular-loading-bar',
    "ui.router",
    "mebo.components",
    "mebo.error"
]);