angular.module('mebo.components').component('navigation', {
    templateUrl: 'components/navigation/navigation.html'
});