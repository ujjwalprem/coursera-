angular.module('mebo.components').component('filterBar', {
    templateUrl: 'components/filterbar/filter-bar.html',
    bindings: {
        filter: "="
    }
});