angular.module('mebo.components').component('messageCreator', {
    templateUrl: 'components/messagecreator/message-creator.html',
    controller: 'MessageCreatorController'
});