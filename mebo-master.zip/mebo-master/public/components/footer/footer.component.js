angular.module('mebo.components').component('footerBar', {
    templateUrl: 'components/footer/footer.html'
});