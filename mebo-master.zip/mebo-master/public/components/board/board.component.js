angular.module('mebo.components').component('board', {
    templateUrl: 'components/board/board.html',
    controller: 'BoardController'
});