angular.module('mebo.components').component('boardCreator', {
    templateUrl: 'components/boardcreator/board-creator.html',
    controller: 'BoardCreatorController'
});