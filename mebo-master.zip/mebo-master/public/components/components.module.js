angular.module("mebo.components", [
    "mebo.service"
]);