angular.module("mebo.error", [

]);