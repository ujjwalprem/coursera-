angular.module('mebo.error').component('errorModal', {
    templateUrl: 'error/modal/error-modal.html'
});